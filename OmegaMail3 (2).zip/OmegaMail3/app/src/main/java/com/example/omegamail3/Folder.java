package com.example.omegamail3;

import java.util.ArrayList;

public class Folder {
    public ArrayList<String> emails;
    public void newAddress(String mail){
        this.emails.add(mail);
    }
}
