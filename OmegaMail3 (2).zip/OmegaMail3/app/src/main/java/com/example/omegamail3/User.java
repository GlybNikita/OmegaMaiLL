package com.example.omegamail3;

import java.util.ArrayList;

public class User {
    public String id, name, password;
    public ArrayList<Account> accs;

    public User(String id, String name, String email, ArrayList accs) {
        this.password = email;
        this.name = name;
        this.id = id;
        this.accs = accs;
    }

    public void addd(Account acc1) {
        this.accs.add(acc1);
    }
}