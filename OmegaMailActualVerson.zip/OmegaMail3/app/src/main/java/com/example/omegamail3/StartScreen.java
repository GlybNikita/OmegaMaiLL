package com.example.omegamail3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.Serializable;
import java.util.ArrayList;

public class StartScreen extends AppCompatActivity {

    private EditText platform, email, passwordn;
    private Button add, next;
    private TextView check;
    private DatabaseReference mydb;
    private String USER_KEY = "User";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.startscreen);

        add = findViewById(R.id.add_email);
        next = findViewById(R.id.next_view);
        platform = findViewById(R.id.platform);
        email = findViewById(R.id.email);
        passwordn = findViewById(R.id.password);
        check = findViewById(R.id.textView);
        mydb = FirebaseDatabase.getInstance().getReference(USER_KEY);

        Bundle arguments = getIntent().getExtras();
        String id = mydb.getKey();
        String name = arguments.getString("name");
        String password = arguments.getString("email");
        ArrayList s = new ArrayList();
        User oldUser = new User(id, name, password, s);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Account acc1 = new Account(platform.getText().toString(), email.getText().toString(), passwordn.getText().toString());
                oldUser.accs.add(acc1);
                email.setText("");
                passwordn.setText("");

            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mydb.push().setValue(oldUser);
                Intent i1 = new Intent(StartScreen.this, ListOfmails.class);
                i1.putExtra("id", oldUser.id);
                i1.putExtra("name", oldUser.name);
                i1.putExtra("email", oldUser.password);
                ArrayList object = oldUser.accs;
                Bundle bundle = new Bundle();
                bundle.putParcelableArrayList("accs", object);
                i1.putExtras(bundle);
                startActivity(i1);
            }
        });
        /*Стартовый экран, в котором пользователь будет вносить аккаунты почтовых сервисов*/

    }
}