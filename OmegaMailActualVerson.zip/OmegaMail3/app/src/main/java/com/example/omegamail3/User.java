package com.example.omegamail3;

import java.util.ArrayList;

public class User {
    public String id, name, password;
    public ArrayList<Account> accs;
    public ArrayList<Folder> folders;


    public User(String id, String name, String email, ArrayList accs) {
        this.password = email;
        this.name = name;
        this.id = id;
        this.accs = accs;
    }
    /*Основной класс-пользователь, сохраняющийся в базу данных и хранящий в себе аккаунты почтовых сервисов и папки для сортировки писем*/
}