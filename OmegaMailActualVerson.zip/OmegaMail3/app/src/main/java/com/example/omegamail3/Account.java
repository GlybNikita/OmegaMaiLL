package com.example.omegamail3;

import java.io.Serializable;

public class Account implements Serializable {
    public String platform, email, password;

    public Account(String platform, String email, String password){
        this.platform = platform;
        this.email = email;
        this.password = password;
        /*класс-аккаунт для входа в почтовые сервисы*/
    }
}
