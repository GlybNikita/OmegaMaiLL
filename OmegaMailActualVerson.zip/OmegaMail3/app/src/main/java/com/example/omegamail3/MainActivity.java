package com.example.omegamail3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText name, email;
    private Button save;

    private DatabaseReference mydb;
    private String USER_KEY = "User";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.editTextTextPersonName);
        email = findViewById(R.id.editTextTextPersonName2);

        save = findViewById(R.id.button);

        mydb = FirebaseDatabase.getInstance().getReference(USER_KEY);//будет появляться группа, которая называется User
        
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String n = name.getText().toString();
                String p = email.getText().toString();
                if(n.contains(" ") || p.contains(" ") || n.length() < 4 || p.length() < 8){
                    name.setText("");
                    email.setText("");
                }
                else{String id = mydb.getKey();
                String name1 = name.getText().toString();
                String password1 = email.getText().toString();
                ArrayList s = new ArrayList();
                User newUser = new User(id, name1, password1, s);
                Intent i1 = new Intent(MainActivity.this, StartScreen.class);
                i1.putExtra("name", newUser.name);
                i1.putExtra("email", newUser.password);
                i1.putExtra("efew", s);
                MainActivity.this.startActivity(i1);}
                /*стартовый экран для входа/регистрации пользователя. Пока что только регистрации.*/
            }
        });
    }
}