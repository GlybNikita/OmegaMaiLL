package com.example.omegamail3;

import java.io.Serializable;
import java.util.ArrayList;

public class Folder implements Serializable {
    public ArrayList<String> emails;
    public void newAddress(String mail){
        this.emails.add(mail);
    }
    /*класс-папка, в котороую входят адреса для сортировки писем*/
}
