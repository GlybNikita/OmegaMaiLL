package com.example.omegamail3;

public class Email {
    public String address, text, time;
    public void Email(String address, String text, String time){
        this.address = address;
        this.text = text;
        this.time = time;
        /*Класс, который будет "впитывать" в себя текст электронного письма, дату отправки и адрес отправителя*/
    }
}
